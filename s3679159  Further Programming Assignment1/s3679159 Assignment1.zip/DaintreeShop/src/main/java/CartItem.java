/**
 * the shopping cart
 */
public class CartItem {

    // book in cart
    private Book book;
    // is ebook
    private boolean isEbook;

    public CartItem(Book book, boolean isEbook) {
        this.book = book;
        this.isEbook = isEbook;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public boolean isEbook() {
        return isEbook;
    }

    public void setEbook(boolean ebook) {
        isEbook = ebook;
    }
}
