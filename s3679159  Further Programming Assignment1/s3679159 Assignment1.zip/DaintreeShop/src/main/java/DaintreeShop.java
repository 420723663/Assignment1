import java.util.Scanner;

/**
 * The main class
 */
public class DaintreeShop {


    // book array
    private static Book[] books;

    // shopping cart
    private static CartItem[] shopCart;


    /**
     * init method
     */
    public static void init() {

        books = new Book[5];

        // add book
        books[0] = new Book("Absolute Java", "Savitch", 5, true);
        books[1] = new Book("JAVA: How to Program", "Deitel and Deitel", 0, true);
        books[2] = new Book("Computing Concepts with JAVA 8 Essentials", "Horstman", 5, false);
        books[3] = new Book("Java Software Solutions", "Lewis and Loftus", 5, false);
        books[4] = new Book("Java Program Design", "Cohoon and Davidson", 1, true);
        shopCart = new CartItem[5];

    }

    /**
     * show menu
     */
    public static void menu() {
        System.out.println("Choose an option:");
        System.out.println("1. Add a book to shopping cart");
        System.out.println("2. View shopping cart");
        System.out.println("3. Remove a book from shopping cart");
        System.out.println("4. Checkout");
        System.out.println("5. List all books");
        System.out.println("0. Quit");
    }

    /**
     * add book to the shopping cart
     *
     * @param book    the book need to add
     * @param isEbook
     */
    public static void addToCart(Book book, boolean isEbook) {

        /**
         * check the book is in shopping cart
         */
        for (int i = 0; i < shopCart.length; i++) {
            CartItem item = shopCart[i];
            if (item != null && item.getBook().getTitle().equals(book.getTitle())) {
                System.out.println("This book is already in Shopping Cart.");
                return;
            }
        }
        /**
         * add book
         */
        for (int i = 0; i < shopCart.length; i++) {
            CartItem item = shopCart[i];
            if (item == null) {
                shopCart[i] = new CartItem(book, isEbook);
                System.out.println("'" + book.getTitle() + "' has been added to your Cart");
                return;
            }
        }


    }

    /**
     * remove book from shopping cart
     *
     * @param book
     */
    public static void removeFromCart(Book book) {
        for (int i = 0; i < shopCart.length; i++) {
            CartItem item = shopCart[i];
            if (item != null && item.getBook().getTitle().equals(book.getTitle())) {
                shopCart[i] = null;
                System.out.println("Item removed from Shopping Cart");
                return;
            }
        }
    }

    public static void main(String[] args) {

        System.out.println("Welcome to Daintree!");
        Scanner in = new Scanner(System.in);
        init();

        while (true) {
            menu();
            System.out.print("Please make a selection:");
            String op = in.nextLine();
            System.out.println();
            // add book
            if (op.equals("1")) {
                addBook(in);
            } else if (op.equals("2")) {
                // view cart
                viewCart();
            } else if (op.equals("3")) {
                // remove book
                removeBook(in);
            } else if (op.equals("4")) {
                // checkout shopping cart
                checkOut();
            } else if (op.equals("5")) {
                // list book
                ListBooks();
            } else if (op.equals("0")) {
                System.out.println("Goodbye!");
                break;
            } else {
                System.out.println("Sorry, that is an invalid option!");
            }
            System.out.println();
        }

    }

    /**
     * list books
     */
    private static void ListBooks() {
        System.out.println("The following titles are available:");
        for (int i = 0; i < books.length; i++) {
            String ebook = "no ebook";
            Book book = books[i];
            if (book.getEbookAvailability()) {
                ebook = "ebook available";
            }
            System.out.println(String.format("%d. %s(%s), %d copies, %s", (i + 1), book.getTitle(), book.getAuthor(), book.getCopies(), ebook));
        }
    }

    /**
     * checkout shopping cart
     */
    private static void checkOut() {
        int sum = 0;
        for (CartItem item : shopCart) {
            if (item != null) {
                if (item.isEbook()) {
                    sum += 8;
                } else {
                    sum += 50;
                    Book book = item.getBook();
                    // reduce copies
                    book.setCopies(book.getCopies() - 1);
                }

            }
        }

        // show the total value
        if (sum <= 0) {
            System.out.println("There is no book in your Shopping Cart.");
        } else {
            System.out.println(String.format("You have purchased items to the total value of $%d.00", sum));
            System.out.println("Thanks for shopping with Daintree!");
            shopCart = new CartItem[5];
        }

    }

    /**
     * remove book from shopping cart
     *
     * @param in
     */
    private static void removeBook(Scanner in) {

        while (true) {
            viewCart();
            System.out.println("0. cancel");
            int[] resultIds = new int[5];
            int idx = 0;
            // save the books index in shopping cart
            for (int i = 0; i < shopCart.length; i++) {
                CartItem item = shopCart[i];
                if (item != null) {
                    resultIds[idx] = i;
                    idx++;
                }
            }

            System.out.print("Which number item do you wish to remove:");
            int number = Integer.parseInt(in.nextLine());
            if (number == 0) {
                break;
            }
            System.out.println("number " + number + "   idx  " + idx);
            if (number > idx) {
                System.out.println("There is no this number item.");
                continue;
            }
            CartItem item = shopCart[resultIds[number - 1]];
            removeFromCart(item.getBook());

            System.out.println();
        }
    }

    /**
     * view shopping cart
     */
    private static void viewCart() {
        System.out.println("Your Shopping Cart contains the following:");
        int idx = 1;
        for (int i = 0; i < shopCart.length; i++) {
            CartItem item = shopCart[i];
            if (item != null) {
                System.out.println(String.format("%d. %s", idx, item.getBook().getTitle()));
                idx++;
            }
        }
    }

    /**
     * add book to the shopping cart
     *
     * @param in
     */
    private static void addBook(Scanner in) {
        System.out.print("Enter title to search for:");
        String title = in.nextLine();
        int idx = 1;
        int[] resultIds = new int[5];
        // save the ids of the search book
        for (int i = 0; i < books.length; i++) {
            Book book = books[i];
            if (book.getTitle().toLowerCase().startsWith(title.toLowerCase())) {
                System.out.println(String.format("%d. %s -- %s", idx, book.getTitle(), book.getAuthor()));
                resultIds[idx - 1] = i;
                idx++;
            }
        }
        if (idx <= 1) {
            System.out.println("There is no title starting with that");
            return;
        }

        System.out.println("0. cancel");

        while (true) {
            System.out.print("Which number item do you wish to purchase:");
            int number = Integer.parseInt(in.nextLine());
            if (number == 0) {
                break;
            }
            if (number >= idx) {
                System.out.println("There is no this number item.");
                continue;
            }
            Book book = books[resultIds[number - 1]];

            System.out.println("Purchasing: " + book.getTitle());
            System.out.print("Do you want to buy this as an ebook:");
            String ebookOp = in.nextLine();

            // add physical copies
            if (ebookOp.equals("no")) {
                // no physical copies
                if (book.getCopies() <= 0) {
                    System.out.println("There are no physical copies of that book available!");
                    continue;
                } else {
                    addToCart(book, false);
                }
            } else {
                // add ebook
                if (book.getEbookAvailability()) {
                    addToCart(book, true);
                } else {
                    System.out.println("There is no ebook available for that title");
                }
            }
            System.out.println();
        }
    }
}
