/**
 * The book class
 */
public class Book {
    // the title of book
    private String title;
    // the author of book
    private String author;
    // the copies of book
    private Integer copies;
    // the ebook of book
    private Boolean ebookAvailability;


    public Book(String title, String author, Integer copies, Boolean ebookAvailability) {
        this.title = title;
        this.author = author;
        this.copies = copies;
        this.ebookAvailability = ebookAvailability;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Integer getCopies() {
        return copies;
    }

    public void setCopies(Integer copies) {
        this.copies = copies;
    }


    public Boolean getEbookAvailability() {
        return ebookAvailability;
    }

    public void setEbookAvailability(Boolean ebookAvailability) {
        this.ebookAvailability = ebookAvailability;
    }
}
