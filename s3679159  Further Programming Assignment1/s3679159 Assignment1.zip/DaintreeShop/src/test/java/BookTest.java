import static org.junit.Assert.*;

import org.junit.Test;

public class BookTest {


    @Test
    public void testTitle() {
        Book book = new Book("Absolute Java", "Savitch", 5, true);
        assertEquals("Absolute Java", book.getTitle());
        book.setTitle("JAVA: How to Program");
        assertEquals("JAVA: How to Program", book.getTitle());
    }

    @Test
    public void testAuthor() {
        Book book = new Book("Absolute Java", "Savitch", 5, true);
        assertEquals("Savitch", book.getAuthor());
        book.setAuthor("Horstman");
        assertEquals("Horstman", book.getAuthor());
    }

    @Test
    public void testEbook() {
        Book book = new Book("Absolute Java", "Savitch", 5, true);
        assertTrue(book.getEbookAvailability());
        book.setEbookAvailability(false);
        assertFalse(book.getEbookAvailability());
    }
}
